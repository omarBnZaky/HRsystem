@extends('layouts.AdminPanel')

@section('content')

<div class="content-wrapper">
<section class="content container-fluid">
<h2>Basic Table</h2>
  <a href="add-employee"><div class="btn btn-success"> Add new employee </div></a>
  <table class="table">
    <thead>
      <tr>
        <th>came at</th>
        <th>gone at</th>
        <th>day</th> 
        <th>Attendence Ratio</th>

      </tr>
    </thead>
    <tbody>
   
    
   @foreach($Employee->attnedences as $attnedence)
   <tr>
   <?php
        $to = \Carbon\Carbon::createFromTimeStamp(strtotime($Employee->from));
        $from = \Carbon\Carbon::createFromTimeStamp(strtotime($Employee->to));
        $diff_in_hours = $to->diffInHours($from);

$Realto = \Carbon\Carbon::createFromTimeStamp(strtotime($attnedence->from));
$Realfrom = \Carbon\Carbon::createFromTimeStamp(strtotime($attnedence->to));

   ?>
    <td>   <?php echo  \Carbon\Carbon::createFromTimeStamp(strtotime($attnedence->from))->format('g:i A') ?> </td>
   <td>   <?php echo  \Carbon\Carbon::createFromTimeStamp(strtotime($attnedence->to))->format('g:i A') ?> </td>
   <td>  <?php echo \Carbon\Carbon::createFromTimeStamp(strtotime($attnedence->day))->format('d D. m M') ?> </td>
   <td>  <?php     $diff_in_Realhours = $Realto->diffInHours($Realfrom);

                      echo  $Ratio = $diff_in_Realhours / $diff_in_hours;


                ?>
    </td>
   </tr>

   @endforeach

</tbody>
  </table>

</section>
</div>


@endsection

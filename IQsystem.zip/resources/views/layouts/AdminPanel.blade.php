@include('layouts.components.head')
@include('layouts.components.header')
@include('layouts.components.aside')
 <!-- Content Wrapper. Contains page content -->
 @yield('content')


  <!-- /.content-wrapper -->

  
@include('layouts.components.footer')

 
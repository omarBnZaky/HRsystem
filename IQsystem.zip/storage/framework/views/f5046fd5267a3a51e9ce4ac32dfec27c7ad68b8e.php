<?php $__env->startSection('content'); ?>
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Dashboard
        <small>Optional description</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
                    <?php if(session('status')): ?>
                    <div class="panel panel-default">
                        <div class="panel-body">
                        <?php echo e(session('status')); ?>

                        </div>
                   </div>
                    <?php endif; ?>
                    
                  
       <div class="row">
       
       <?php if(Auth::user()->id == 1): ?>
       <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo e($usersCount); ?></h3>

              <p>Main members</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="All-members" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
    </div> 
       <?php else: ?>
     <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <?php if($role->id == 1): ?>

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo e($AllusersExpectAdminCount); ?></h3>

              <p>Main members</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="All-members" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
    </div> 
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


    
    </section>
    <!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminPanel', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
<section class="content container-fluid">

  <h2>Basic Table</h2>
  <a href="add-member"><div class="btn btn-success"> Add new User </div></a>
  <table class="table">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>John</td>
        <td>Doe</td>
        <td>john@example.com</td>
      </tr>
      <tr>
        <td>Mary</td>
        <td>Moe</td>
        <td>mary@example.com</td>
      </tr>
      <tr>
        <td>July</td>
        <td>Dooley</td>
        <td>july@example.com</td>
      </tr>
    </tbody>
  </table>
  </section>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminPanel', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
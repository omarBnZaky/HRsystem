<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
<section class="content container-fluid">
<h2>Basic Table</h2>
  <a href="add-employee"><div class="btn btn-success"> Add new employee </div></a>
  <table class="table">
    <thead>
      <tr>
        <th>came at</th>
        <th>gone at</th>
        <th>day</th> 
        <th>Attendence Ratio</th>

      </tr>
    </thead>
    <tbody>
   
    
   <?php $__currentLoopData = $Employee->attnedences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attnedence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
   <?php
        $to = \Carbon\Carbon::createFromTimeStamp(strtotime($Employee->from));
        $from = \Carbon\Carbon::createFromTimeStamp(strtotime($Employee->to));
        $diff_in_hours = $to->diffInHours($from);

$Realto = \Carbon\Carbon::createFromTimeStamp(strtotime($attnedence->from));
$Realfrom = \Carbon\Carbon::createFromTimeStamp(strtotime($attnedence->to));

   ?>
    <td>   <?php echo  \Carbon\Carbon::createFromTimeStamp(strtotime($attnedence->from))->format('g:i A') ?> </td>
   <td>   <?php echo  \Carbon\Carbon::createFromTimeStamp(strtotime($attnedence->to))->format('g:i A') ?> </td>
   <td>  <?php echo \Carbon\Carbon::createFromTimeStamp(strtotime($attnedence->day))->format('d D. m M') ?> </td>
   <td>  <?php     $diff_in_Realhours = $Realto->diffInHours($Realfrom);

                      echo  $Ratio = $diff_in_Realhours / $diff_in_hours;


                ?>
    </td>
   </tr>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tbody>
  </table>

</section>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminPanel', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
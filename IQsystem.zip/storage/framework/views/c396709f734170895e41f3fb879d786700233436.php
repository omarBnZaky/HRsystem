<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
<section class="content container-fluid">
<h2>Edit member</h2>

<?php echo e(Html::ul($errors->all())); ?>


<form method="POST" action="/edit-member/<?php echo e($user->id); ?>"> 
<?php echo csrf_field(); ?>
<div class="form-group">
      <label for="name">name:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" value="<?php echo e($user->name); ?>">
    </div>
<div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" value="<?php echo e($user->email); ?>"">
    </div>
    <div class="form-group">
      <label for="pwd">oldPassword:</label>
      <input type="password" class="form-control" id="password" placeholder="Enter old password" name="oldPassword">
    </div>
    
    <div class="form-group">
      <label for="pwd">New Password:</label>
      <input type="password" class="form-control" id="password" placeholder="Enter new password" name="password"> 
    </div>
    <div class="form-group">
      <label for="role">Role:</label><br>
      current roles:  <br>
      <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div style="width:60px;background-color:green;color:white;border-radius:50px 50px" class="text-center"><?php echo e($role->name); ?></div>
 <a href="<?php echo e($user->id); ?>/delete-user-role/<?php echo e($role->id); ?>" style="border-radius:50px 50px"><div class="btn btn-danger">Delete role</div></a>
  <br>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <select class="form-control" name="role_id"> 
      <?php $__currentLoopData = $Roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($Role->id); ?>"><?php echo e($Role->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
</select> 

      </div>
    <button type="submit" class="btn btn-success">Submit</button>
  </form>


</section>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminPanel', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
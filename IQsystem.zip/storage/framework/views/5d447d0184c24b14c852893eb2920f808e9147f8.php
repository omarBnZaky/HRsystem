<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
<section class="content container-fluid">
<h2>give member permision</h2>
<form method="POST" action="/Add-role/<?php echo e($user->id); ?>/{role_id}"> 
<?php echo csrf_field(); ?>
<div class="form-group">
 <select class="form-control">
        <option value="0">....</option>
      
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
    <button type="submit" class="btn btn-success">add this role for <?php echo e($user->name); ?></button>
  </form>


</section>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminPanel', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
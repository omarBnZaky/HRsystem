<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
<section class="content container-fluid">
                              <?php if(session('status')): ?>
                                     <?php echo e(session('status')); ?>  
                            <?php endif; ?>
                            
                            <?php if(session('msg')): ?>
                                     <?php echo e(session('msg')); ?>  
                            <?php endif; ?>
<?php if(Auth::user()->id == 1): ?>
  <h2>Basic Table</h2>
  <a href="add-employee"><div class="btn btn-success"> Add new employee </div></a>
  <table class="table">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Email</th>
        <th>holidays</th> 
        <th>Action</th> 
        <th>Add by</th> 

      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $AllEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($Employee->name); ?></td>
        <td><?php echo e($Employee->email); ?></td>
        <td>
            <?php $__currentLoopData = $Employee->holidays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holiday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="text-info"><?php echo e($holiday->holiday); ?>  </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td> 
        <form method="POST" action="remove-employee/<?php echo e($Employee->id); ?>" >
        <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">delete </button>
       </form>
           <a href="edit-employee/<?php echo e($Employee->id); ?>">
            <div class="btn btn-info">edit</div>
           </a>
           
           <a href="employee-attendence/<?php echo e($Employee->id); ?>">
            <div class="btn btn-info">attendence</div>
           </a>
          </td>
          <td><?php echo e($Employee->user->name); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  </section>
</div>
<?php else: ?>

<h2>Basic Table</h2>
  <a href="add-employee"><div class="btn btn-success"> Add new employee </div></a>
  <table class="table">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Email</th>
        <th>holidays</th> 
        <th>Action</th> 

      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $AllEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($Employee->user_id == Auth::user()->id): ?>

    <tr>
        <td><?php echo e($Employee->name); ?></td>
        <td><?php echo e($Employee->email); ?></td>
        <td>
            <?php $__currentLoopData = $Employee->holidays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holiday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="text-info"><?php echo e($holiday->holiday); ?>  </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td> 
        <form method="POST" action="remove-employee/<?php echo e($Employee->id); ?>" >
        <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">delete </button>
       </form>
           <a href="edit-employee/<?php echo e($Employee->id); ?>">
            <div class="btn btn-warning">edit</div>
           </a>
           <a href="employee-attendence/<?php echo e($Employee->id); ?>">
            <div class="btn btn-info">attendence</div>
           </a>
          </td>
      </tr>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  </section>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminPanel', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
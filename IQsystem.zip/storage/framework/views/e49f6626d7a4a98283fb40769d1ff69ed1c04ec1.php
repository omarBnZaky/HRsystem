<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
<section class="content container-fluid">
<h2>Edit an  Employee</h2>

<?php echo e(Html::ul($errors->all())); ?>


<form method="POST" action="/edit_employee/<?php echo e($Employee->id); ?>"> 
<?php echo csrf_field(); ?>
<div class="form-group">
      <label for="name">name:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" value="<?php echo e($Employee->name); ?>">
    </div>
<div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" value="<?php echo e($Employee->email); ?>"">
    </div>
    <div class="form-group">
      <label for="pwd">oldPassword:</label>
      <input type="password" class="form-control" id="password" placeholder="Enter old password" name="oldPassword">
    </div>
    
    <div class="form-group">
      <label for="pwd">New Password:</label>
      <input type="password" class="form-control" id="password" placeholder="Enter new password" name="password"> 
    </div>
    <div class="form-group">
      <label for="role">Holidays:</label><br>
      <?php $__currentLoopData = $Employee->holidays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holiday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div style="width:60px;background-color:green;color:white;border-radius:50px 50px" class="text-center"><?php echo e($holiday->holiday); ?></div>
 <a href="<?php echo e($Employee->id); ?>/delete-employee-holiday/<?php echo e($holiday->id); ?>" style="border-radius:50px 50px"><div class="btn btn-danger">Delete holiday</div></a>
  <br>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
 <div class="form-group">
        <label for="off_days">holidays:</label>
        <input type="checkbox" name="saturday"   value="saturday"> saturday
        <input type="checkbox" name="sunday"     value="sunday"> sunday 
        <input type="checkbox" name="monday"     value="monday"> monday 
        <input type="checkbox" name="tuesday"    value="tuesday"> tuesday 
        <input type="checkbox" name="wednesday"  value="wednesday"> wednesday 
        <input type="checkbox" name="thursday"   value="thursday"> thursday 
        <input type="checkbox" name="friday"     value="friday"> friday 
    </div>

      </div>
    <button type="submit" class="btn btn-success">Submit</button>
  </form>


</section>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminPanel', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>